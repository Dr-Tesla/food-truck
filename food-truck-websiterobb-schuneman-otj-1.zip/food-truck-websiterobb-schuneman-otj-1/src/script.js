$('.hidden-on-load').animate({
  opacity: 1
}, 8000)

// icon
// menu section
// Mathematician's Favorites
// Location
// Hours